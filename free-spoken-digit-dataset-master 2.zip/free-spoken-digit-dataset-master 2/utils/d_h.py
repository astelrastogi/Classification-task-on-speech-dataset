import matplotlib
import numpy as np
import sklearn.model_selection
import sklearn.preprocessing
import matplotlib.pyplot as plt
import sys
import os
import fsdd


s,l=fsdd.FSDD.get_spectrograms("/Users/aastharastogi/Downloads/free-spoken-digit-dataset-master 2/spectrograms")


from sklearn.model_selection import train_test_split
s_train, s_test, l_train, l_test = train_test_split(s, l, test_size=0.1)


from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(s_train, l_train)
print('Accuracy of Logistic regression classifier on training set: {:.2f}'
     .format(logreg.score(s_train, l_train)))
print('Accuracy of Logistic regression classifier on test set: {:.2f}'
     .format(logreg.score(s_test, l_test)))
